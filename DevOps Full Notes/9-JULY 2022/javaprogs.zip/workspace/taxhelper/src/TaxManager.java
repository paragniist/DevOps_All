package com.ngpayroll.tax;
public class TaxManager {
	public double getTaxAmount(double grossSalary, String gender) {
		double taxAmount = 0;
		if(gender.equals("female")) {
			if(grossSalary > 500000) {
				taxAmount = ((grossSalary - 500000) * 10) / 100;
			}
		}else {
			if(grossSalary > 250000) {
				taxAmount = ((grossSalary - 250000) * 10) / 100;
			}
		}
		return taxAmount;
	}
}
