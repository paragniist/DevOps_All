package com.jdops.runner;

import java.security.SecureRandom;

public class Main {
	public static void main(String[] args) {
           SecureRandom random = new SecureRandom();
	   int lucky = random.nextInt(100);
	   System.out.println("lucky :" + lucky);
	}
}
