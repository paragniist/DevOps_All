package com.chatbox.runner;
import java.util.Scanner;

public class Messenger {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ready!");
		String message = scanner.nextLine();
		System.out.println("sending message : "+ message +" over messenger....");
	}
}
