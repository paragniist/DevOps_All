package com.ngconnect.tools;
import java.time.*;

public class AppointmentManager {
	public String newAppointment(String patientName, String doctorName, LocalDateTime appointmentDate, String mobileNo) {
		System.out.println("Your appointment with doctor: " + doctorName + " is confirmed, please arrive 15 minutes prior to appointment time");
		return "939";
	}
}
