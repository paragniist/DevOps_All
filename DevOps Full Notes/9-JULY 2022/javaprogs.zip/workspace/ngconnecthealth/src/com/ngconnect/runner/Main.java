package com.ngconnect.runner;
import com.ngconnect.tools.AppointmentManager;
import java.time.*;

public class Main {
	public static void main(String[] args) {
		AppointmentManager am = new AppointmentManager();
		String appointmentNo = am.newAppointment("Matt", "Mark", LocalDateTime.of(2022, 7, 15, 10, 1), "93893933");
		System.out.println("appointmentNo : " + appointmentNo);
	}
}
