package com.ngpayroll.runner;

import com.ngpayroll.manager.PayrollManager;
import java.util.*;

public class Main {
  public static void main(String[] args) {
    PayrollManager payrollManager = new PayrollManager();
    Scanner scanner = new Scanner(System.in);
    System.out.print("gross salary: ");
    double grossSalary = scanner.nextDouble();
    System.out.print("gender :");
    scanner.nextLine();
    String gender = scanner.nextLine();
    double payAmount = payrollManager.netPay(grossSalary, gender);
    System.out.println("Net Salary : " + payAmount);
  }
}
