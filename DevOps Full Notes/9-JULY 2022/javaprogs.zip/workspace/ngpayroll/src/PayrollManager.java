package com.ngpayroll.manager;
import com.ngpayroll.tax.TaxManager;

public class PayrollManager {
  public double netPay(double grossSalary, String gender) {
    double netPay = 0;
    double taxAmount = 0;
    TaxManager taxManager = null;
    taxManager = new TaxManager();
    taxAmount = taxManager.getTaxAmount(grossSalary, gender);
    netPay = grossSalary - taxAmount;
    return netPay;
  }
}
