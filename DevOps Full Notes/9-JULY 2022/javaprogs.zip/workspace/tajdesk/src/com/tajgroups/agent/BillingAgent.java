package com.tajgroups.agent;
import com.probytes.manager.BillManager;

public class BillingAgent {
	public double getMemberBill(String itemCode, int quantity) {
		BillManager billingManager = new BillManager();
		double amount = billingManager.getBillAmount(itemCode, quantity);
		double disAmount = amount - (amount * 10)/100;
		return disAmount;
	}
}
