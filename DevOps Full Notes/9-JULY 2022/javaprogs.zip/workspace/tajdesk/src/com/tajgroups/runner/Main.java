package com.tajgroups.runner;
import com.tajgroups.agent.BillingAgent;

public class Main {
	public static void main(String[] args) {
		BillingAgent agent = new BillingAgent();
		double amt = agent.getMemberBill("item1", 2);
		System.out.println("bill amount : " + amt);
	}
}
