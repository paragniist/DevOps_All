package com.philips.electronics;
public class Thermostat {
  public static void main(String[] args) {
    System.out.println("thermostat from Philips!");
  }
}
