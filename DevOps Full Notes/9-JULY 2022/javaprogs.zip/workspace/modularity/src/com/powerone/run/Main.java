package com.powerone.run;
import com.powerone.labs.Laboratory;

public class Main {
  public static void main(String[] args) {
    Laboratory laboratory = new Laboratory();
    laboratory.analyze("water");
  }
}
