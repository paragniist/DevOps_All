package com.powerone.tools;
public class ChemicalAnalyzer {
  public String analyze(String material) {
    return "co2";
  }
}
