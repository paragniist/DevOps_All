package com.probytes.manager;
public class BillManager {
	public double getBillAmount(String itemCode, int quatity) {
		return 938.75;
	}
}
